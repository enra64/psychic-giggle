/**
 * This package contains miscellaneous classes.
 */
package de.ovgu.softwareprojekt.misc;