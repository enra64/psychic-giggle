/**
 * This package contains the pipeline splitters that have already been implemented. Splitters are used to redirect data
 * depending on certain conditions, like which client the data is from.
 */
package de.ovgu.softwareprojekt.pipeline.splitters;