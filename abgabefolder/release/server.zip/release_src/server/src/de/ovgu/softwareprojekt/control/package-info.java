/**
 * This package contains classes pertaining the control flow used in both the server and the app.
 */
package de.ovgu.softwareprojekt.control;