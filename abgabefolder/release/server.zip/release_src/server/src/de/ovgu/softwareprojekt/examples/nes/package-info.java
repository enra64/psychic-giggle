/**
 * The nes package contains an example of using the framework as a nes controller substitute.
 */
package de.ovgu.softwareprojekt.examples.nes;