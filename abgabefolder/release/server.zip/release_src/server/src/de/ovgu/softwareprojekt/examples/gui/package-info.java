/**
 * Contains the graphical user interface written for the three example usages
 */
package de.ovgu.softwareprojekt.examples.gui;