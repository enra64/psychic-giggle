/**
 * The kuka package contains a simple control example for a kuka LBR iiwa 7.
 */
package de.ovgu.softwareprojekt.examples.kuka;