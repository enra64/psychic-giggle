/**
 * The mouse package contains an example usage of the framework which lets you move your mouse cursor by moving your phone.
 */
package de.ovgu.softwareprojekt.examples.mouse;