/**
 * This package contains all common classes, that is classes used in both the server and the app.
 */
package de.ovgu.softwareprojekt;