/**
 * The graphing package contains a simple live data plotting graph to ease development using sensor data.
 */
package de.ovgu.softwareprojekt.examples.graphing;