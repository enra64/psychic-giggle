/**
 * The pipeline package contains all classes used for directing or modifying the data flow.
 */
package de.ovgu.softwareprojekt.pipeline;