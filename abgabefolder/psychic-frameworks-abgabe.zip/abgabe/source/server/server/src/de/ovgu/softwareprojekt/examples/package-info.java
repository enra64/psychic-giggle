/**
 * Contains all of the example framework usages written by the softwareprojekt team
 */
package de.ovgu.softwareprojekt.examples;