/**
 * The util package contains a small amount of generic util functions.
 */
package de.ovgu.softwareprojekt.util;