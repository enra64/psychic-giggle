/**
 * This package contains classes pertaining the discovery system in both server and app.
 */
package de.ovgu.softwareprojekt.discovery;