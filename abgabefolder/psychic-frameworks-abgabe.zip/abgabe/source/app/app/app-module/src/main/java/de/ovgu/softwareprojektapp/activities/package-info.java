/**
 * All activity code
 */
package de.ovgu.softwareprojektapp.activities;