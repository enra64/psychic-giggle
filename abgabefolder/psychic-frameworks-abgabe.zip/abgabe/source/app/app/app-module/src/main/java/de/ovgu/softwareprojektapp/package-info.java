/**
 * This package contains all classes used for the app except the ones in the common part.
 */
package de.ovgu.softwareprojektapp;