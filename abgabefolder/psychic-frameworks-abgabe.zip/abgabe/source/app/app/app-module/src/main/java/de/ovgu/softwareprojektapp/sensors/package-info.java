/**
 * Contains all classes needed to handle the sensor communication and activation state.
 */
package de.ovgu.softwareprojektapp.sensors;