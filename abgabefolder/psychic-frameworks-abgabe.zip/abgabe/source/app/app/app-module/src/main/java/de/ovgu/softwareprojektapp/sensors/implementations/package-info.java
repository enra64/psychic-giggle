/**
 * Contains all {@link de.ovgu.softwareprojektapp.sensors.AbstractSensor} implementations, and thus
 * all sensor classes known to the framework
 */
package de.ovgu.softwareprojektapp.sensors.implementations;