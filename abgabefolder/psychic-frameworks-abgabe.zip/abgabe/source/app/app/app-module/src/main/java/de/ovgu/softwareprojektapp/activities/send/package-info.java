/**
 * Code for the {@link de.ovgu.softwareprojektapp.activities.send.SendActivity}. Also contains the
 * {@link de.ovgu.softwareprojektapp.activities.send.LayoutParser} class, which displays layouts sent
 * via {@link de.ovgu.softwareprojekt.control.commands.UpdateButtonsXML}.
 */
package de.ovgu.softwareprojektapp.activities.send;