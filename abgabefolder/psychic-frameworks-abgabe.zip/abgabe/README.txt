Den passenden SNES-Emulator für alle Plattformen findet man unter http://www.snes9x.com/downloads.php.
Die PsychicSensors-App lässt sich am einfachsten aus dem Google PlayStore herunterladen: https://play.google.com/store/apps/details?id=de.ovgu.softwareprojektapp
